Q .Display hours minuts and second
   for current time (use date command)

#!/bin/sh
date +%T
